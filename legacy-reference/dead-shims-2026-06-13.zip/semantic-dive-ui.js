export function syncSemanticDiveUi() {}
