import { state, withStateMutation } from '../state.js';
import { updateClusterList, populateCityFilter } from './cluster-filter.js';
import { buildLegend } from './ui-renderers.js';
import { applyFilters } from './search-state.js';
import { normalizeSlugName } from './utils/data-mapper.js';
import { debugWarn } from './diagnostic-adapter.js';

let _dataWorker = null;

function buildAssetUrl(path) {
    if (typeof window === 'undefined') return path;
    return new URL(path, window.location.href).href;
}

function getWorker() {
    if (typeof Worker === 'undefined') {
        _dataWorker = null;
        return null;
    }
    if (_dataWorker) return _dataWorker;

    try {
        _dataWorker = new Worker('js/workers/data-worker.js');
        return _dataWorker;
    } catch (err) {
        console.warn('Web Worker instantiation failed, using main-thread fallback.', err);
        return null;
    }
}

/**
 * Promise-based wrapper for worker communication.
 */
function callWorker(type, payload) {
    return new Promise((resolve, reject) => {
        const worker = getWorker();
        if (!worker) {
            reject(new Error('Worker unavailable'));
            return;
        }

        const handler = (event) => {
            const { type: resType, payload: resPayload } = event.data;
            if (resType === `${type}_SUCCESS`) {
                worker.removeEventListener('message', handler);
                resolve(resPayload);
            } else if (resType === 'ERROR') {
                worker.removeEventListener('message', handler);
                _dataWorker = null;
                reject(new Error(resPayload?.message || 'Worker failed'));
            }
        };

        worker.addEventListener('message', handler);
        worker.postMessage({ type, payload });
    });
}

export async function loadData() {
    let lastError;
    state.dataLoadAttempt = (state.dataLoadAttempt || 0) + 1;
    const attemptNumber = state.dataLoadAttempt;
    const maxAttempts = 3;
    const dataUrl = buildAssetUrl(`data.dat?v=6&t=${Date.now()}`);
    const enrichmentUrl = buildAssetUrl(`scripts/leadEnrichment.public.json?v=1&t=${Date.now()}`);

    // 1. Attempt Worker-Based Loading
    const worker = getWorker();
    if (worker) {
        try {
            const [{ points, pointIndexByLeadId, positionsBuffer, clustersBuffer }, enrichment] = await Promise.all([
                callWorker('LOAD_RECORDS', { url: dataUrl }),
                fetchEnrichment(enrichmentUrl).catch((err) => {
debugWarn('Enrichment fetch failed, continuing without it.', err);
      return null;
                })
            ]);
            // Normalize slug-style names at load time so downstream consumers
            // (search, journey, info panel) never see raw corpus-seed slugs.
            const normalizedPoints = points.map(p => ({ ...p, name: normalizeSlugName(p.name) }));
            withStateMutation(() => {
                if (state.dataLoadAttempt !== attemptNumber) return;
                state.points = normalizedPoints;
                state.leadEnrichment = enrichment;
                state.pointIndexByLeadId = new Map(Object.entries(pointIndexByLeadId));
                state.rawPositionsBuffer = positionsBuffer;
                state.rawClustersBuffer = clustersBuffer;
            });
            finalizeLoading();
            return;
        } catch (err) {
            console.warn('Worker-based data loading failed, falling back to main thread.', err);
            _dataWorker = null;
            lastError = err;
        }
    }

    // 2. Main-Thread Fallback
    const [raw, enrichment] = await Promise.all([
        fetchDataWithRetries(dataUrl, maxAttempts),
    fetchEnrichment(enrichmentUrl).catch((err) => {
      debugWarn('Enrichment fetch failed, continuing without it.', err);
            return null;
        })
    ]);

    if (!raw || !Array.isArray(raw)) {
        withStateMutation(() => {
            state.points = [];
            state.pointIndexByLeadId = new Map();
            state.leadEnrichment = enrichment;
            state.projectedNeighborGrid = null;
            state.projectedNeighborCache = new Map();
            state.rawPositionsBuffer = null;
            state.rawClustersBuffer = null;
        });
        const detail = lastError?.message ? ` Last error: ${lastError.message}` : '';
        throw new Error(`Unable to load county records after ${maxAttempts} attempts.${detail}`);
    }

    const count = raw.length;
    const positionsBuffer = new Float32Array(count * 3);
    const clustersBuffer = new Uint16Array(count);

    const points = raw.map((p, i) => {
        const x = p.length > 0 ? parseFiniteNumber(p[0]) : 0;
        const y = p.length > 1 ? parseFiniteNumber(p[1]) : 0;
        const z = p.length > 2 ? parseFiniteNumber(p[2]) : 0;
        const cluster = p.length > 3 ? (parseInt(p[3], 10) || 0) : 0;

        positionsBuffer[i * 3] = x;
        positionsBuffer[i * 3 + 1] = y;
        positionsBuffer[i * 3 + 2] = z;
        clustersBuffer[i] = cluster;

        return {
            cluster,
            name: p.length > 4 ? normalizeSlugName(cleanOptionalValue(p[4])) : null,
            what: p.length > 5 ? cleanOptionalValue(p[5]) || 'Montgomery County business' : 'Montgomery County business',
            city: p.length > 6 ? cleanOptionalValue(p[6]) || 'Montgomery County' : 'Montgomery County',
            lead_id: p.length > 7 ? p[7] : null,
            lat: p.length > 8 ? parseFiniteNumber(p[8]) : null,
            lng: p.length > 9 ? parseFiniteNumber(p[9]) : null,
            website: p.length > 10 ? cleanOptionalValue(p[10]) : null,
            email: p.length > 11 ? cleanOptionalValue(p[11]) : null,
            phone: p.length > 12 ? cleanOptionalValue(p[12]) : null,
            trivia: p.length > 13 ? cleanOptionalValue(p[13]) : null,
            status: p.length > 14 ? cleanOptionalValue(p[14]) || 'active' : 'active',
            // NAICS code (e.g. "624410" or "611512"). Optional column added in
            // 2026-06-04 by scripts/augment_data.py. Records without a NAICS
            // fall through to text matching in the search code.
            naics: p.length > 15 ? cleanOptionalValue(p[15]) : null
        };
    });

    withStateMutation(() => {
        if (state.dataLoadAttempt !== attemptNumber) return;
        state.points = points;
        state.leadEnrichment = enrichment;
        state.rawPositionsBuffer = positionsBuffer;
        state.rawClustersBuffer = clustersBuffer;
        state.pointIndexByLeadId = new Map();
        state.points.forEach((point, index) => {
            if (point.lead_id !== null && point.lead_id !== undefined && point.lead_id !== '') {
                state.pointIndexByLeadId.set(String(point.lead_id), index);
            }
        });
    });

    finalizeLoading();
}

async function fetchDataWithRetries(dataUrl, maxAttempts) {
    let lastError;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
            const response = await fetch(dataUrl);
            if (!response.ok) throw new Error(`Failed to fetch data: ${response.status}`);
            try {
                return await response.json();
            } catch (jsonErr) {
                throw new Error(`Invalid JSON in data.dat: ${jsonErr.message}`, { cause: jsonErr });
            }
        } catch (err) {
            lastError = err;
            if (attempt < maxAttempts) {
                await new Promise((r) => setTimeout(r, 500 * attempt));
            }
        }
    }
    const detail = lastError?.message ? ` Last error: ${lastError.message}` : '';
    throw new Error(`Unable to load county records after ${maxAttempts} attempts.${detail}`);
}

async function fetchEnrichment(url) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Failed to fetch enrichment: ${response.status}`);
    return response.json();
}

function checkDataBounds(buffer) {
    if (!buffer || buffer.length === 0) return;

    // Stride-sample the full buffer: check up to 600 floats spread evenly
    // across the entire positions array so out-of-bounds values at the end
    // of large datasets are no longer missed.
    const MAX_SAMPLES = 600;
    const totalFloats = buffer.length;
    const step = totalFloats <= MAX_SAMPLES ? 1 : Math.ceil(totalFloats / MAX_SAMPLES);
    const oobValues = [];

    for (let i = 0; i < totalFloats; i += step) {
        const val = buffer[i];
        if (val < -0.1 || val > 1.1) {
            oobValues.push({ index: i, value: val });
        }
    }

    if (oobValues.length > 0) {
        const samples = oobValues.slice(0, 10).map(
            (o) => `  index ${o.index}: ${o.value}`
        ).join('\n');
        const more = oobValues.length > 10
            ? `\n  ...and ${oobValues.length - 10} more out-of-bounds values.`
            : '';
        console.error(
            `CRITICAL: data.dat positions are out of bounds! ` +
            `Found ${oobValues.length} value(s) outside [0, 1]:\n${samples}${more}\n` +
            `The 3D engine expects coordinates to be normalized strictly to [0, 1]. ` +
            `MYCELIUM_FIELD_SCALE will cause extreme camera scaling and rendering issues. ` +
            `Please re-run the backend normalization script.`
        );
    }
}

function finalizeLoading() {
    checkDataBounds(state.rawPositionsBuffer);
    state.projectedNeighborGrid = null;
    state.projectedNeighborCache = new Map();

    const totalCountEl = document.getElementById('total-count');
    if (totalCountEl) totalCountEl.textContent = state.points.length.toLocaleString();

    try {
        if (typeof updateClusterList === 'function') updateClusterList();
        if (typeof buildLegend === 'function') buildLegend();
        if (typeof populateCityFilter === 'function') populateCityFilter();
        if (typeof applyFilters === 'function') applyFilters();
    } catch (err) {
        debugWarn('Post-load UI refresh failed:', err);
    }
}

const NULLISH_SENTINELS = new Set([
    'unknown', 'not found', 'none', 'none detected', 'n/a', 'null'
]);

function cleanOptionalValue(value) {
    if (value === undefined || value === null || value === '') return null;
    const text = String(value).trim();
    if (!text || text === 'NULL' || NULLISH_SENTINELS.has(text.toLowerCase())) {
        return null;
    }
    return text;
}

function parseFiniteNumber(value) {
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
}
